# Original Sol 6.1 editorial evidence, 2026-10-29 to 2026-11-01

This preservation package contains the **unmodified binary bytes** of four original GitHub Actions artifact ZIPs. The inner ZIPs were downloaded from their original GitHub Actions runs; their SHA-256 checksums match GitHub's artifact metadata and the canonical `evidence-index.json`. All 42 inner manifest hashes were verified against the actual archived file contents.

The canonical original documentation, already committed to the repository, is:

- `RESULTS_AND_RESTART.md`: https://github.com/Herurg123/ai-svodki-ia/blob/main/automation/audits/experiments/2026-10-29-sol61-editorial-shadow/RESULTS_AND_RESTART.md
- `evidence-index.json`: https://github.com/Herurg123/ai-svodki-ia/blob/main/automation/audits/experiments/2026-10-29-sol61-editorial-shadow/evidence-index.json

This bundle does not contain user Billing CSV, credentials, or API secrets. The complete Terra requests and independent Sol outputs **are included**, so this archive must be treated as public evidence if committed to this public GitHub repository. No historical ZIP has been reconstructed from the final report.

**V1**: 2026-10-29 to 2026-10-31 (compact-selection). **V2**: 2026-11-01 (exact-input full editorial). The two versions are not directly comparable.

The source artifacts have limited retention in GitHub Actions, but a copy committed to Git stays in repository history unless that history or the repository is removed.
