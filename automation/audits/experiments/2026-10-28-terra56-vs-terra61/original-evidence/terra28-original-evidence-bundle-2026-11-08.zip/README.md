# Terra 5.6 vs Terra 6.1, 28 October 2026: original evidence bundle

This archive preserves **four unmodified original GitHub Actions artifact ZIPs**. No reconstructed result is represented as original evidence.

## Completeness boundary

- **Terra 5.6 full original** `daily-production-2026-10-28`, artifact `12786364155`: **MISSING**. Its historically recorded SHA-256 is `33a9c898549a289163bbafd7528e0d4043afc4b2ff72389f59c7649513ef4bd5` and its recorded size is `76,530,263` bytes. The owner reports no local copy, and the original is no longer listed in its GitHub Actions run. No byte-identical full original is available. Do not recreate one from partial files or label any substitute as the missing original.
- **Terra 5.6 research, coverage, image checkpoints**: three *original*, independent `actions/upload-artifact` ZIPs downloaded from run `40618839186` on 2026-11-08. They are preserved for partial inspection but do not replace the missing full final ZIP.
- **Terra 6.1 shadow**: original ZIP from run `40629579368`, artifact `12791765194`; ZIP SHA-256 matches the SHA published in the historical `RESULT.md`.

## Authentication and publishing review

Known third-party `static2.finnhub.io` PDF URLs contain a query parameter named `Authorization`. The owner explicitly decided this third-party URL does not concern them and authorized ignoring it in the original ZIP. The ZIPs include raw model/research outputs and prompts, so public Git history will permanently expose this content. A pattern-based scan found no typical PEM private key, bearer header, GitHub PAT, AWS key, or Google API key; **this is not proof that no sensitive information exists**. The original ZIPs are stored unchanged.

## Verification

Inspect `MANIFEST.json` for source run IDs, artifact IDs, sizes, per-ZIP entry counts, expiration dates, and original hashes. Check individual ZIP SHA-256 values against `SHA256SUMS.txt` and run `unzip -t` on each original.

This package was built locally by wrapping downloaded original ZIPs without extracting/rebuilding them. The original ZIP bytes are unchanged.

## Scope and provenance

A/B study documentation remains in `automation/audits/experiments/2026-10-28-terra56-vs-terra61/RESULT.md`, `PLAN.md`, and `EVENTS.md`. Data limitations and experimental caveats described there remain in force. No provider API requests, workflow launches, deployment or publication occur in archiving.
